<!DOCTYPE html>
<html class="no-js" lang="en-US">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="pingback" href="">
<meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v28.5 - https://yoast.com/product/yoast-seo-wordpress/ -->
	<title>Page not found - comicbookreadingorders</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - comicbookreadingorders" />
	<meta property="og:site_name" content="comicbookreadingorders" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https:\/\/schema.org","@graph":[{"@type":"WebSite","@id":"https:\/\/comicbookreadingorders.com\/#website","url":"https:\/\/comicbookreadingorders.com\/","name":"comicbookreadingorders","description":"Start Reading","publisher":{"@id":"https:\/\/comicbookreadingorders.com\/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https:\/\/comicbookreadingorders.com\/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"en-US"},{"@type":"Organization","@id":"https:\/\/comicbookreadingorders.com\/#organization","name":"comicbookreadingorders","url":"https:\/\/comicbookreadingorders.com\/","logo":{"@type":"ImageObject","inLanguage":"en-US","@id":"https:\/\/comicbookreadingorders.com\/#\/schema\/logo\/image\/","url":"https:\/\/comicbookreadingorders.com\/wp-content\/uploads\/main.header.svg","contentUrl":"https:\/\/comicbookreadingorders.com\/wp-content\/uploads\/main.header.svg","width":1,"height":1,"caption":"comicbookreadingorders"},"image":{"@id":"https:\/\/comicbookreadingorders.com\/#\/schema\/logo\/image\/"},"sameAs":["https:\/\/x.com\/comicbookro"]}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//www.googletagmanager.com' />
<link rel="alternate" type="application/rss+xml" title="comicbookreadingorders &raquo; Feed" href="https://comicbookreadingorders.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="comicbookreadingorders &raquo; Comments Feed" href="https://comicbookreadingorders.com/comments/feed/" />
<style id="wp-img-auto-sizes-contain-inline-css">
img:is([sizes=auto i],[sizes^="auto," i]){contain-intrinsic-size:3000px 1500px}
/*# sourceURL=wp-img-auto-sizes-contain-inline-css */
</style>

<style id="wp-emoji-styles-inline-css">

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
/*# sourceURL=wp-emoji-styles-inline-css */
</style>
<style id="wp-block-library-inline-css">
:root{--wp-block-synced-color:#7a00df;--wp-block-synced-color--rgb:122,0,223;--wp-bound-block-color:var(--wp-block-synced-color);--wp-editor-canvas-background:#ddd;--wp-admin-theme-color:#007cba;--wp-admin-theme-color--rgb:0,124,186;--wp-admin-theme-color-darker-10:#006ba1;--wp-admin-theme-color-darker-10--rgb:0,107,160.5;--wp-admin-theme-color-darker-20:#005a87;--wp-admin-theme-color-darker-20--rgb:0,90,135;--wp-admin-border-width-focus:2px}@media (min-resolution:192dpi){:root{--wp-admin-border-width-focus:1.5px}}.wp-element-button{cursor:pointer}:root .has-very-light-gray-background-color{background-color:#eee}:root .has-very-dark-gray-background-color{background-color:#313131}:root .has-very-light-gray-color{color:#eee}:root .has-very-dark-gray-color{color:#313131}:root .has-vivid-green-cyan-to-vivid-cyan-blue-gradient-background{background:linear-gradient(135deg,#00d084,#0693e3)}:root .has-purple-crush-gradient-background{background:linear-gradient(135deg,#34e2e4,#4721fb 50%,#ab1dfe)}:root .has-hazy-dawn-gradient-background{background:linear-gradient(135deg,#faaca8,#dad0ec)}:root .has-subdued-olive-gradient-background{background:linear-gradient(135deg,#fafae1,#67a671)}:root .has-atomic-cream-gradient-background{background:linear-gradient(135deg,#fdd79a,#004a59)}:root .has-nightshade-gradient-background{background:linear-gradient(135deg,#330968,#31cdcf)}:root .has-midnight-gradient-background{background:linear-gradient(135deg,#020381,#2874fc)}:root{--wp--preset--font-size--normal:16px;--wp--preset--font-size--huge:42px}.has-regular-font-size{font-size:1em}.has-larger-font-size{font-size:2.625em}.has-normal-font-size{font-size:var(--wp--preset--font-size--normal)}.has-huge-font-size{font-size:var(--wp--preset--font-size--huge)}:root .has-text-align-center{text-align:center}:root .has-text-align-left{text-align:left}:root .has-text-align-right{text-align:right}.has-fit-text{white-space:nowrap!important}#end-resizable-editor-section{display:none}.aligncenter{clear:both}.items-justified-left{justify-content:flex-start}.items-justified-center{justify-content:center}.items-justified-right{justify-content:flex-end}.items-justified-space-between{justify-content:space-between}.screen-reader-text{word-wrap:normal!important;border:0;clip-path:inset(50%);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px;word-break:normal!important}.screen-reader-text:focus{background-color:#ddd;clip-path:none;color:#444;display:block;font-size:1em;height:auto;left:5px;line-height:normal;padding:15px 23px 14px;text-decoration:none;top:5px;width:auto;z-index:100000}html :where(.has-border-color){border-style:solid}html :where([style^=border-color],[style*=";border-color"],[style*="; border-color"]){border-style:solid}html :where([style^=border-top-color],[style*=";border-top-color"],[style*="; border-top-color"]){border-top-style:solid}html :where([style^=border-right-color],[style*=";border-right-color"],[style*="; border-right-color"]){border-right-style:solid}html :where([style^=border-bottom-color],[style*=";border-bottom-color"],[style*="; border-bottom-color"]){border-bottom-style:solid}html :where([style^=border-left-color],[style*=";border-left-color"],[style*="; border-left-color"]){border-left-style:solid}html :where([style^=border-width],[style*=";border-width"],[style*="; border-width"]){border-style:solid}html :where([style^=border-top-width],[style*=";border-top-width"],[style*="; border-top-width"]){border-top-style:solid}html :where([style^=border-right-width],[style*=";border-right-width"],[style*="; border-right-width"]){border-right-style:solid}html :where([style^=border-bottom-width],[style*=";border-bottom-width"],[style*="; border-bottom-width"]){border-bottom-style:solid}html :where([style^=border-left-width],[style*=";border-left-width"],[style*="; border-left-width"]){border-left-style:solid}html :where(img[class*=wp-image-]){height:auto;max-width:100%}:where(figure){margin:0 0 1em}html :where(.is-position-sticky){--wp-admin--admin-bar--position-offset:var(--wp-admin--admin-bar--height,0px)}@media screen and (max-width:600px){html :where(.is-position-sticky){--wp-admin--admin-bar--position-offset:0px}}

/*# sourceURL=/wp-includes/css/dist/block-library/common.min.css */
</style>
<style id="classic-theme-styles-inline-css">
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
/*# sourceURL=/wp-includes/css/classic-themes.min.css */
</style>

<style id="global-styles-inline-css">
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgb(6,147,227) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgb(252,185,0) 0%,rgb(255,105,0) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgb(255,105,0) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgb(255, 255, 255), 6px 6px rgb(0, 0, 0);--wp--preset--shadow--crisp: 6px 6px 0px rgb(0, 0, 0);}.wp-block-button{--wp--preset--dimension--25: 25%;--wp--preset--dimension--50: 50%;--wp--preset--dimension--75: 75%;--wp--preset--dimension--100: 100%;}:where(body) { margin: 0; }:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}body{padding-top: 0px;padding-right: 0px;padding-bottom: 0px;padding-left: 0px;}:root :where(.wp-element-button, .wp-block-button__link){background-color: #32373c;border-width: 0;color: #fff;font-family: inherit;font-size: inherit;font-style: inherit;font-weight: inherit;letter-spacing: inherit;line-height: inherit;padding-top: calc(0.667em + 2px);padding-right: calc(1.333em + 2px);padding-bottom: calc(0.667em + 2px);padding-left: calc(1.333em + 2px);text-decoration: none;text-transform: inherit;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
/*# sourceURL=global-styles-inline-css */
</style>

<link rel='stylesheet' id='patreon-wordpress-css-css' href='https://comicbookreadingorders.com/wp-content/plugins/patron-plugin-pro/plugin/lib/patreon-connect/assets/css/app.css?ver=1.9.17' media='all' />
<link rel='stylesheet' id='x-stack-css' href='https://comicbookreadingorders.com/wp-content/themes/pro/framework/dist/css/site/stacks/integrity-light.css?ver=6.9.4' media='all' />
<link rel='stylesheet' id='x-child-css' href='https://comicbookreadingorders.com/wp-content/themes/pro-child/style.css?ver=6.9.4' media='all' />
<link rel='stylesheet' id='cb_p6-css-main-css' href='https://comicbookreadingorders.com/wp-content/plugins/patron-plugin-pro/plugin/lib/patron-button-and-widgets-by-codebard/plugin/templates/default/style.css?ver=7.1' media='all' />
<link rel='stylesheet' id='cb_p6_a1-css-main-css' href='https://comicbookreadingorders.com/wp-content/plugins/patron-plugin-pro/plugin/templates/default/style.css?ver=2.0.4' media='all' />
<style id="cs-inline-css">
@media (min-width:1200px){.x-hide-xl{display:none !important;}}@media (min-width:979px) and (max-width:1199px){.x-hide-lg{display:none !important;}}@media (min-width:767px) and (max-width:978px){.x-hide-md{display:none !important;}}@media (min-width:480px) and (max-width:766px){.x-hide-sm{display:none !important;}}@media (max-width:479px){.x-hide-xs{display:none !important;}}:root{--x-layout-site-width:100%;--x-layout-site-max-width:960px;--x-h1-letter-spacing:0em;--x-h2-letter-spacing:0em;--x-h3-letter-spacing:0em;--x-h4-letter-spacing:0em;--x-h5-letter-spacing:0em;--x-h6-letter-spacing:0em;} a,h1 a:hover,h2 a:hover,h3 a:hover,h4 a:hover,h5 a:hover,h6 a:hover,.x-breadcrumb-wrap a:hover,.widget ul li a:hover,.widget ol li a:hover,.widget.widget_text ul li a,.widget.widget_text ol li a,.widget_nav_menu .current-menu-item > a,.x-accordion-heading .x-accordion-toggle:hover,.x-comment-author a:hover,.x-comment-time:hover,.x-recent-posts a:hover .h-recent-posts{color:#e42525;}a:hover,.widget.widget_text ul li a:hover,.widget.widget_text ol li a:hover,.x-twitter-widget ul li a:hover{color:#febd11;}.rev_slider_wrapper,a.x-img-thumbnail:hover,.x-slider-container.below,.page-template-template-blank-3-php .x-slider-container.above,.page-template-template-blank-6-php .x-slider-container.above{border-color:#e42525;}.entry-thumb:before,.x-pagination span.current,.woocommerce-pagination span[aria-current],.flex-direction-nav a,.flex-control-nav a:hover,.flex-control-nav a.flex-active,.mejs-time-current,.x-dropcap,.x-skill-bar .bar,.x-pricing-column.featured h2,.h-comments-title small,.x-entry-share .x-share:hover,.x-highlight,.x-recent-posts .x-recent-posts-img:after{background-color:#e42525;}.x-nav-tabs > .active > a,.x-nav-tabs > .active > a:hover{box-shadow:inset 0 3px 0 0 #e42525;}.x-main{width:calc(72% - 2.463055%);}.x-sidebar{width:calc(100% - 2.463055% - 72%);}.x-comment-author,.x-comment-time,.comment-form-author label,.comment-form-email label,.comment-form-url label,.comment-form-rating label,.comment-form-comment label,.widget_calendar #wp-calendar caption,.widget.widget_rss li .rsswidget{font-family:"Lato",sans-serif;font-weight:400;}.p-landmark-sub,.p-meta,input,button,select,textarea{font-family:"Lato",sans-serif;}.widget ul li a,.widget ol li a,.x-comment-time{color:#3a3a3a;}.widget_text ol li a,.widget_text ul li a{color:#e42525;}.widget_text ol li a:hover,.widget_text ul li a:hover{color:#febd11;}.comment-form-author label,.comment-form-email label,.comment-form-url label,.comment-form-rating label,.comment-form-comment label,.widget_calendar #wp-calendar th,.p-landmark-sub strong,.widget_tag_cloud .tagcloud a:hover,.widget_tag_cloud .tagcloud a:active,.entry-footer a:hover,.entry-footer a:active,.x-breadcrumbs .current,.x-comment-author,.x-comment-author a{color:#272727;}.widget_calendar #wp-calendar th{border-color:#272727;}.h-feature-headline span i{background-color:#272727;}@media (max-width:978.98px){}html{font-size:14px;}@media (min-width:500px){html{font-size:calc(14px + (16 - 14) * ((100vw - 500px) / (1000 - 500)));}}@media (min-width:1000px){html{font-size:16px;}}body{font-style:normal;font-weight:400;color:#3a3a3a;background:rgb(193,193,193);}.w-b{font-weight:400 !important;}h1,h2,h3,h4,h5,h6,.h1,.h2,.h3,.h4,.h5,.h6,.x-text-headline{font-family:"Lato",sans-serif;font-style:normal;font-weight:400;}h1,.h1{letter-spacing:var(--x-h1-letter-spacing,0em);}h2,.h2{letter-spacing:var(--x-h2-letter-spacing,0em);}h3,.h3{letter-spacing:var(--x-h3-letter-spacing,0em);}h4,.h4{letter-spacing:var(--x-h4-letter-spacing,0em);}h5,.h5{letter-spacing:var(--x-h5-letter-spacing,0em);}h6,.h6{letter-spacing:var(--x-h6-letter-spacing,0em);}.w-h{font-weight:400 !important;}.x-container.width{width:var(--x-layout-site-width,100%);}.x-container.max{max-width:var(--x-layout-site-max-width,960px);}.x-bar-content.x-container.width{flex-basis:var(--x-layout-site-width,100%);}.site,.x-site{width:var(--x-layout-site-width,100%);max-width:var(--x-layout-site-max-width,960px);}.x-main.full{float:none;clear:both;display:block;width:auto;}@media (max-width:978.98px){.x-main.full,.x-main.left,.x-main.right,.x-sidebar.left,.x-sidebar.right{float:none;display:block;width:auto !important;}}.entry-header,.entry-content{font-size:1rem;}body,input,button,select,textarea{font-family:"Lato",sans-serif;}h1,h2,h3,h4,h5,h6,.h1,.h2,.h3,.h4,.h5,.h6,h1 a,h2 a,h3 a,h4 a,h5 a,h6 a,.h1 a,.h2 a,.h3 a,.h4 a,.h5 a,.h6 a,blockquote{color:#272727;}.cfc-h-tx{color:#272727 !important;}.cfc-h-bd{border-color:#272727 !important;}.cfc-h-bg{background-color:#272727 !important;}.cfc-b-tx{color:#3a3a3a !important;}.cfc-b-bd{border-color:#3a3a3a !important;}.cfc-b-bg{background-color:#3a3a3a !important;}.x-btn,.button,[type="submit"]{color:#ffffff;border-color:#020000;background-color:#e42525;text-shadow:0 0.075em 0.075em rgba(0,0,0,0.5);border-radius:0.25em;padding:0.429em 1.143em 0.643em;font-size:14px;}.x-btn:hover,.button:hover,[type="submit"]:hover{color:#020202;border-color:#020000;background-color:#febd11;text-shadow:0 0.075em 0.075em rgba(0,0,0,0.5);}.x-btn.x-btn-real,.x-btn.x-btn-real:hover{margin-bottom:0.25em;text-shadow:0 0.075em 0.075em rgba(0,0,0,0.65);}.x-btn.x-btn-real{box-shadow:0 0.25em 0 0 #a71000,0 4px 9px rgba(0,0,0,0.75);}.x-btn.x-btn-real:hover{box-shadow:0 0.25em 0 0 #a71000,0 4px 9px rgba(0,0,0,0.75);}.x-btn.x-btn-flat,.x-btn.x-btn-flat:hover{margin-bottom:0;text-shadow:0 0.075em 0.075em rgba(0,0,0,0.65);box-shadow:none;}.x-btn.x-btn-transparent,.x-btn.x-btn-transparent:hover{margin-bottom:0;border-width:3px;text-shadow:none;text-transform:uppercase;background-color:transparent;box-shadow:none;}.x-topbar .p-info a:hover,.x-widgetbar .widget ul li a:hover{color:#e42525;}.x-topbar .p-info,.x-topbar .p-info a,.x-navbar .desktop .x-nav > li > a,.x-navbar .desktop .sub-menu a,.x-navbar .mobile .x-nav li > a,.x-breadcrumb-wrap a,.x-breadcrumbs .delimiter{color:#000000;}.x-navbar .desktop .x-nav > li > a:hover,.x-navbar .desktop .x-nav > .x-active > a,.x-navbar .desktop .x-nav > .current-menu-item > a,.x-navbar .desktop .sub-menu a:hover,.x-navbar .desktop .sub-menu .x-active > a,.x-navbar .desktop .sub-menu .current-menu-item > a,.x-navbar .desktop .x-nav .x-megamenu > .sub-menu > li > a,.x-navbar .mobile .x-nav li > a:hover,.x-navbar .mobile .x-nav .x-active > a,.x-navbar .mobile .x-nav .current-menu-item > a{color:#e42525;}.x-navbar .desktop .x-nav > li > a:hover,.x-navbar .desktop .x-nav > .x-active > a,.x-navbar .desktop .x-nav > .current-menu-item > a{box-shadow:inset 0 4px 0 0 #e42525;}.x-navbar .desktop .x-nav > li > a{height:90px;padding-top:30px;}.x-navbar-fixed-top-active .x-navbar-wrap{margin-bottom:1px;}.x-navbar .desktop .x-nav > li ul{top:calc(90px - 15px);}@media (max-width:979px){.x-navbar-fixed-top-active .x-navbar-wrap{margin-bottom:0;}}.x-navbar.x-navbar-fixed-top.x-container.max.width{width:100%%;max-width:960pxpx;}.x-btn-widgetbar{border-top-color:#febd11;border-right-color:#febd11;}.x-btn-widgetbar:hover{border-top-color:#e42525;border-right-color:#e42525;}body.x-navbar-fixed-top-active .x-navbar-wrap{height:90px;}.x-navbar-inner{min-height:90px;}.x-logobar-inner{padding-top:0px;padding-bottom:0px;}.x-brand{font-family:"Lato",sans-serif;font-size:42px;font-style:normal;font-weight:700;letter-spacing:0.019em;color:#272727;}.x-brand:hover,.x-brand:focus{color:#272727;}.x-brand img{width:calc(1920px / 2);}.x-navbar .x-nav-wrap .x-nav > li > a{font-family:"Lato",sans-serif;font-style:normal;font-weight:400;letter-spacing:0em;text-transform:uppercase;}.x-navbar .desktop .x-nav > li > a{font-size:24px;}.x-navbar .desktop .x-nav > li > a:not(.x-btn-navbar-woocommerce){padding-left:18px;padding-right:18px;}.x-navbar .desktop .x-nav > li > a > span{margin-right:-0em;}.x-btn-navbar{margin-top:16px;}.x-btn-navbar,.x-btn-navbar.collapsed{font-size:30px;}@media (max-width:979px){.x-navbar.x-navbar-fixed-top.x-container.max.width{left:0;right:0;width:100%;}body.x-navbar-fixed-top-active .x-navbar-wrap{height:auto;}.x-widgetbar{left:0;right:0;}}.bg .mejs-container,.x-video .mejs-container{position:unset !important;} @font-face{font-family:'FontAwesomePro';font-style:normal;font-weight:900;font-display:block;src:url('https://comicbookreadingorders.com/wp-content/themes/pro/cornerstone/assets/fonts/fa-solid-900.woff2?ver=7.3.1') format('woff2');}[data-x-fa-pro-icon]{font-family:"FontAwesomePro" !important;}[data-x-fa-pro-icon]:before{content:attr(data-x-fa-pro-icon);}[data-x-icon],[data-x-icon-o],[data-x-icon-l],[data-x-icon-s],[data-x-icon-b],[data-x-icon-sr],[data-x-icon-ss],[data-x-icon-sl],[data-x-icon-d],[data-x-fa-pro-icon],[class*="cs-fa-"]{display:inline-flex;font-style:normal;font-weight:400;text-decoration:inherit;text-rendering:auto;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;}[data-x-icon].left,[data-x-icon-o].left,[data-x-icon-l].left,[data-x-icon-s].left,[data-x-icon-b].left,[data-x-icon-sr].left,[data-x-icon-ss].left,[data-x-icon-sl].left,[data-x-fa-pro-icon].left,[class*="cs-fa-"].left{margin-right:0.5em;}[data-x-icon].right,[data-x-icon-o].right,[data-x-icon-l].right,[data-x-icon-s].right,[data-x-icon-b].right,[data-x-icon-sr].right,[data-x-icon-ss].right,[data-x-icon-sl].right,[data-x-fa-pro-icon].right,[class*="cs-fa-"].right{margin-left:0.5em;}[data-x-icon]:before,[data-x-icon-o]:before,[data-x-icon-l]:before,[data-x-icon-s]:before,[data-x-icon-b]:before,[data-x-icon-sr]:before,[data-x-icon-ss]:before,[data-x-icon-sl]:before,[data-x-fa-pro-icon]:before,[class*="cs-fa-"]:before{line-height:1;}@font-face{font-family:'FontAwesome';font-style:normal;font-weight:900;font-display:block;src:url('https://comicbookreadingorders.com/wp-content/themes/pro/cornerstone/assets/fonts/fa-solid-900.woff2?ver=7.3.1') format('woff2');}[data-x-icon],[data-x-icon-s],[data-x-icon][class*="cs-fa-"]{font-family:"FontAwesome" !important;font-weight:900;}[data-x-icon]:before,[data-x-icon][class*="cs-fa-"]:before{content:attr(data-x-icon);}[data-x-icon-s]:before{content:attr(data-x-icon-s);}@font-face{font-family:'FontAwesomeRegular';font-style:normal;font-weight:400;font-display:block;src:url('https://comicbookreadingorders.com/wp-content/themes/pro/cornerstone/assets/fonts/fa-regular-400.woff2?ver=7.3.1') format('woff2');}@font-face{font-family:'FontAwesomePro';font-style:normal;font-weight:400;font-display:block;src:url('https://comicbookreadingorders.com/wp-content/themes/pro/cornerstone/assets/fonts/fa-regular-400.woff2?ver=7.3.1') format('woff2');}[data-x-icon-o]{font-family:"FontAwesomeRegular" !important;}[data-x-icon-o]:before{content:attr(data-x-icon-o);}@font-face{font-family:'FontAwesomeLight';font-style:normal;font-weight:300;font-display:block;src:url('https://comicbookreadingorders.com/wp-content/themes/pro/cornerstone/assets/fonts/fa-light-300.woff2?ver=7.3.1') format('woff2');}@font-face{font-family:'FontAwesomePro';font-style:normal;font-weight:300;font-display:block;src:url('https://comicbookreadingorders.com/wp-content/themes/pro/cornerstone/assets/fonts/fa-light-300.woff2?ver=7.3.1') format('woff2');}[data-x-icon-l]{font-family:"FontAwesomeLight" !important;font-weight:300;}[data-x-icon-l]:before{content:attr(data-x-icon-l);}@font-face{font-family:'FontAwesomeBrands';font-style:normal;font-weight:normal;font-display:block;src:url('https://comicbookreadingorders.com/wp-content/themes/pro/cornerstone/assets/fonts/fa-brands-400.woff2?ver=7.3.1') format('woff2');}[data-x-icon-b]{font-family:"FontAwesomeBrands" !important;}[data-x-icon-b]:before{content:attr(data-x-icon-b);}.widget.widget_rss li .rsswidget:before{content:"\f35d";padding-right:0.4em;font-family:"FontAwesome";} .m60o-0.x-bar{height:auto;border-top-width:0;border-right-width:0;border-bottom-width:0;border-left-width:0;font-size:1em;background-color:#ffffff;box-shadow:0px 3px 25px 0px rgba(0,0,0,0.15);z-index:9999;}.m60o-0 .x-bar-content{display:flex;flex-direction:row;justify-content:space-between;align-items:center;height:auto;}.m60o-0.x-bar-outer-spacers:after,.m60o-0.x-bar-outer-spacers:before{flex-basis:20px;width:20px!important;height:20px;}.m60o-0.x-bar-space{font-size:1em;}.m60o-1.x-bar-container{display:flex;flex-direction:row;justify-content:space-between;align-items:center;flex-grow:1;flex-shrink:0;flex-basis:auto;border-top-width:0;border-right-width:0;border-bottom-width:0;border-left-width:0;font-size:1em;z-index:auto;} .x-logobar-inner .x-container-fluid.max,.x-brand.img{width:100%;max-width:100%;}.x-logobar .x-container.max.width{width:100%;max-width:100%;}.h-custom-headline.red-class.accent span:before,.h-custom-headline.red-class.accent span:after{border-color:#e42525;}.h-custom-headline.yellow-class.accent span:before,.h-custom-headline.yellow-class.accent span:after{border-color:#febd11;}.h-custom-headline.blue-class.accent span:before,.h-custom-headline.blue-class.accent span:after{border-color:#0066aa;}a.dc-class:link{color:#0066aa !important;}a.dc-class:hover{color:#febd11 !important;}a.dc-class:visited{color:#0066aa;}@media (min-width:768px ){.x-columnize-three{-webkit-column-count:3 !important;-moz-column-count:3 !important;column-count:3 !important;}}@media (min-width:768px ){.x-columnize-four{-webkit-column-count:4 !important;-moz-column-count:4 !important;column-count:4 !important;}}.x-columnize.red-col{-moz-column-rule:1px solid #e42525;}.x-columnize.blue-col{-moz-column-rule:1px solid #0066aa;}.x-prompt-section.x-prompt-section-button{display:none;}.x-prompt{border:none;box-shadow:none;}a.marvel-class:link{color:#e42525 !important;}a.marvel-class:hover{color:#febd11 !important;}a.marvel-class:visited{color:#e42525;}.x-scroll-top.right {right:25%;}body .x-scroll-top{border:2px solid #e42525 !important;color:#e42525 !important;opacity:1 !important;filter:alpha(opacity=100) !important;zoom:1 !important;}.x-breadcrumbs{padding-left:4%;}a:focus,select:focus,input[type="file"]:focus,input[type="radio"]:focus,input[type="submit"]:focus,input[type="checkbox"]:focus{outline:none;}.x-navbar .mobile .x-nav > li > a{padding:20px !important;}.entry-content a{font-weight:700;}a.nbold{font-weight:normal;}.grecaptcha-badge{visibility:hidden;}a{white-space:nowrap;}a.issue:link{color:#000000cc !important;font-weight:normal;}a.issue:hover{color:#febd11 !important;}a.issue:visited{color:#e42525;}
/*# sourceURL=cs-inline-css */
</style>
<script id="jquery-core-js" src="https://comicbookreadingorders.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1"></script>
<script id="jquery-migrate-js" src="https://comicbookreadingorders.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1"></script>

<!-- Google tag (gtag.js) snippet added by Site Kit -->
<!-- Google Analytics snippet added by Site Kit -->
<script id="google_gtagjs-js" src="https://www.googletagmanager.com/gtag/js?id=G-3LVCH0054Z" async></script>
<script id="google_gtagjs-js-after">
window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}
gtag("set","linker",{"domains":["comicbookreadingorders.com"]});
gtag("js", new Date());
gtag("set", "developer_id.dZTNiMT", true);
gtag("config", "G-3LVCH0054Z");
//# sourceURL=google_gtagjs-js-after
</script>
<link rel="https://api.w.org/" href="https://comicbookreadingorders.com/wp-json/" /><meta name="generator" content="Site Kit by Google 1.187.0" /><style>@font-face {
            font-family: 'Libre Franklin Extra Bold';
            src: url('https://comicbookreadingorders.com/wp-content/plugins/patron-plugin-pro/plugin/lib/patreon-connect/assets/fonts/librefranklin-extrabold-webfont.woff2') format('woff2'),
                 url('https://comicbookreadingorders.com/wp-content/plugins/patron-plugin-pro/plugin/lib/patreon-connect/assets/fonts/librefranklin-extrabold-webfont.woff') format('woff');
            font-weight: bold;
            }</style><style id="mpp-unlock-button-styles">
.mpp-cta-button {
    display: inline-block;
    padding: 15px 24px;
    margin: 15px 0;
    background-color: #FF6B35 !important;
    color: #FFFFFF !important;
    text-decoration: none;
    font-weight: bold;
    font-size: 16px;
    border-radius: 4px;
    text-align: center;
    cursor: pointer;
    border: none;
    line-height: 1.4;
}
.mpp-cta-button:hover {
    background-color: #E55A2B !important;
    color: #FFFFFF !important;
}
</style>
<link rel="icon" href="https://comicbookreadingorders.com/wp-content/uploads/cbro.circle.01.svg" sizes="32x32" />
<link rel="icon" href="https://comicbookreadingorders.com/wp-content/uploads/cbro.circle.01.svg" sizes="192x192" />
<link rel="apple-touch-icon" href="https://comicbookreadingorders.com/wp-content/uploads/cbro.circle.01.svg" />
<meta name="msapplication-TileImage" content="https://comicbookreadingorders.com/wp-content/uploads/cbro.circle.01.svg" />
<style id="wp-custom-css">
/*
You can add your own CSS here.

Click the help icon above to learn more.
*/

/* submenu font size */
.desktop .sub-menu li>a {
    font-size: 14px;
}
</style>
<link rel="stylesheet" href="//fonts.googleapis.com/css?family=Lato:400,400i,700,700i&#038;subset=latin,latin-ext&#038;display=auto" type="text/css" media="all" crossorigin="anonymous" data-x-google-fonts/></head>
<body class="error404 wp-theme-pro wp-child-theme-pro-child x-integrity x-integrity-light x-child-theme-active x-boxed-layout-active x-full-width-active x-post-meta-disabled x-navbar-fixed-top-active pro-v6_9_4">

  <div class="x-skip-links"><a class="x-skip-link" href="#x-main">Skip to content</a></div>
  
  <div id="x-root" class="x-root">

    
    <div id="top" class="site">

    <header class="masthead masthead-stacked" role="banner">


  <div class="x-logobar">
    <div class="x-logobar-inner">
      <div class="x-container max width">
        
<a href="https://comicbookreadingorders.com/" class="x-brand img">
  <img src="//comicbookreadingorders.com/wp-content/uploads/main.header.svg" alt="comicbookreadingorders"></a>
      </div>
    </div>
  </div>

  <div class="x-navbar-wrap">
    <div class="x-navbar">
      <div class="x-navbar-inner">
        <div class="x-container max width">
          
<a href="#" id="x-btn-navbar" class="x-btn-navbar collapsed" data-x-toggle="collapse-b" data-x-toggleable="x-nav-wrap-mobile" aria-expanded="false" aria-controls="x-nav-wrap-mobile" role="button">
  <i class='x-framework-icon x-icon-bars' data-x-icon-s='&#xf0c9;' aria-hidden=true></i>  <span class="visually-hidden">Navigation</span>
</a>

<nav class="x-nav-wrap desktop" role="navigation">
  <ul id="menu-main" class="x-nav"><li id="menu-item-53" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-53"><a href="https://comicbookreadingorders.com/marvel/"><span>Marvel<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a>
<ul class="sub-menu">
	<li id="menu-item-80" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-80"><a href="https://comicbookreadingorders.com/marvel/events/"><span>Marvel Events<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
	<li id="menu-item-79" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-79"><a href="https://comicbookreadingorders.com/marvel/characters/"><span>Marvel Characters<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
	<li id="menu-item-135" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-135"><a href="https://comicbookreadingorders.com/marvel/marvel-master-reading-order/"><span>Marvel Master Reading Order<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
</ul>
</li>
<li id="menu-item-76" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-76"><a href="https://comicbookreadingorders.com/dc/"><span>DC<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a>
<ul class="sub-menu">
	<li id="menu-item-78" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-78"><a href="https://comicbookreadingorders.com/dc/events/"><span>DC Events<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
	<li id="menu-item-77" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-77"><a href="https://comicbookreadingorders.com/dc/characters/"><span>DC Characters<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
	<li id="menu-item-248" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-248"><a href="https://comicbookreadingorders.com/dc/dc-master-reading-order/"><span>DC Master Reading Order<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
</ul>
</li>
<li id="menu-item-89" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-89"><a href="https://comicbookreadingorders.com/other/"><span>Other<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
<li id="menu-item-5795" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5795"><a href="https://comicbookreadingorders.com/updates/"><span>Updates<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
<li id="menu-item-74" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-74"><a href="https://comicbookreadingorders.com/faq/"><span>FAQ<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
<li id="menu-item-75" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-75"><a href="https://comicbookreadingorders.com/contact/"><span>Contact<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
<li class="menu-item x-menu-item x-menu-item-search"><a href="#" class="x-btn-navbar-search" aria-label="Navigation Search"><span><i class='x-framework-icon x-icon-search' data-x-icon-s='&#xf002;' aria-hidden=true></i><span class="x-hidden-desktop"> Search</span></span></a></li></ul></nav>

<div id="x-nav-wrap-mobile" class="x-nav-wrap mobile x-collapsed" data-x-toggleable="x-nav-wrap-mobile" data-x-toggle-collapse="1" aria-hidden="true" aria-labelledby="x-btn-navbar">
  <ul id="menu-main-1" class="x-nav"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-53"><a href="https://comicbookreadingorders.com/marvel/"><span>Marvel<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-80"><a href="https://comicbookreadingorders.com/marvel/events/"><span>Marvel Events<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-79"><a href="https://comicbookreadingorders.com/marvel/characters/"><span>Marvel Characters<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-135"><a href="https://comicbookreadingorders.com/marvel/marvel-master-reading-order/"><span>Marvel Master Reading Order<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-76"><a href="https://comicbookreadingorders.com/dc/"><span>DC<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-78"><a href="https://comicbookreadingorders.com/dc/events/"><span>DC Events<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-77"><a href="https://comicbookreadingorders.com/dc/characters/"><span>DC Characters<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-248"><a href="https://comicbookreadingorders.com/dc/dc-master-reading-order/"><span>DC Master Reading Order<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-89"><a href="https://comicbookreadingorders.com/other/"><span>Other<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5795"><a href="https://comicbookreadingorders.com/updates/"><span>Updates<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-74"><a href="https://comicbookreadingorders.com/faq/"><span>FAQ<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-75"><a href="https://comicbookreadingorders.com/contact/"><span>Contact<i class="x-icon x-framework-icon x-framework-icon-menu" aria-hidden="true" data-x-icon-s="&#xf103;"></i></span></a></li>
<li class="menu-item x-menu-item x-menu-item-search"><a href="#" class="x-btn-navbar-search" aria-label="Navigation Search"><span><i class='x-framework-icon x-icon-search' data-x-icon-s='&#xf002;' aria-hidden=true></i><span class="x-hidden-desktop"> Search</span></span></a></li></ul></div>

        </div>
      </div>
    </div>
  </div>


  
    <div class="x-breadcrumb-wrap">
      <div class="x-container max width">

        <div class="x-breadcrumbs" itemscope itemtype="http://schema.org/BreadcrumbList" aria-label="Breadcrumb Navigation"><span itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemtype="http://schema.org/Thing" itemprop="item" href="https://comicbookreadingorders.com/" class=""><span itemprop="name"><span class="home"><i class='x-framework-icon x-icon-home' data-x-icon-s='&#xf015;' aria-hidden=true></i></span><span class="visually-hidden">Home</span></span></a> <span class="delimiter"><i class='x-framework-icon x-icon-angle-right' data-x-icon-s='&#xf105;' aria-hidden=true></i></span> <meta itemprop="position" content="1"></span><span itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><a itemtype="http://schema.org/Thing" itemprop="item" href="https://comicbookreadingorders.com/marvel/events/moz-extension:/541a6bdc-df7d-413c-96d8-93c64446b6d0/js/app.js/" title="You Are Here" class="current "><span itemprop="name">404 (Page Not Found)</span></a><meta itemprop="position" content="2"></span></div>
        
      </div>
    </div>

  </header>

  <header class="x-header-landmark x-container max width">
    <h1 class="h-landmark"><span>Oops!</span></h1>
    <p class="p-landmark-sub"><span>You blew up the Internet. </span></p>
  </header>


  <div class="x-container max width offset">
    <div id="x-main" class="x-main full" role="main" tabindex="-1">
      <div class="entry-wrap entry-404">

        
<p class="center-text">The page you are looking for is no longer here, or never existed in the first place (bummer). You can try searching for what you are looking for using the form below. If that still doesn't provide the results you are looking for, you can always start over from the home page.</p>

<form method="get" id="searchform" class="form-search" action="https://comicbookreadingorders.com/">
  <div class="x-form-search-icon-wrapper">
    <i class='x-framework-icon x-form-search-icon' data-x-icon-s='&#xf002;' aria-hidden=true></i>  </div>
  <label for="s" class="visually-hidden">Search</label>
  <input type="text" id="s" name="s" class="search-query" placeholder="Search" />
</form>

      </div>
    </div>
  </div>


    

  <footer class="x-colophon" role="contentinfo">

    
    <div class="x-bar x-bar-footer x-bar-h x-bar-relative e7800-e1 m60o-0" data-x-bar="{&quot;id&quot;:&quot;e7800-e1&quot;,&quot;region&quot;:&quot;footer&quot;,&quot;height&quot;:&quot;auto&quot;}"><div class="e7800-e1 x-bar-content x-container max width"><div class="x-bar-container e7800-e2 m60o-1"><footer class="x-colophon bottom" role="contentinfo">
      <div class="x-container max width">

        
                  <div class="x-social-global"><a href="https://twitter.com/ComicBookRO" class="twitter" title="X / Twitter" target="_blank" rel=""><i class="fa-brands fa-square-x-twitter" data-x-icon-b='&#xe61a;' aria-hidden=true></i></a>        
        					<a href="https://www.patreon.com/comicbookreadingorders" class="patreon" title="Patreon" target="_blank" rel=""><i class="fa-brands fa-patreon" data-x-icon-b='&#xf3d9;' aria-hidden=true></i></a></div>
                  <div class="x-colophon-content">
            <p style="padding-left: 60px; padding-right: 60px;" class="mtn">We are a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for us to earn fees by linking to Amazon.com and affiliated sites.</p>          </div>
        
      </div>
    </footer></div></div></div>
    
  </footer>


      <div class="x-searchform-overlay">
        <div class="x-searchform-overlay-inner">
          <div class="x-container max width">
            <form method="get" id="searchform" class="form-search center-text" action="https://comicbookreadingorders.com/">
              <label for="s" class="cfc-h-tx tt-upper">Type and Press &ldquo;enter&rdquo; to Search</label>
              <input type="text" id="s" class="search-query cfc-h-tx center-text tt-upper" name="s">
                           </form>
          </div>
        </div>
      </div>

      
    </div> <!-- END .x-site -->

    
    <div id="x-widgetbar" class="x-widgetbar x-collapsed" data-x-toggleable="x-widgetbar" data-x-toggle-collapse="1" aria-hidden="true" aria-labelledby="x-btn-widgetbar">
      <div class="x-widgetbar-inner">
        <div class="x-container max width">

          <div class="x-column x-md x-1-1 last"></div>
        </div>
      </div>
    </div>

    <a href="#" id="x-btn-widgetbar" class="x-btn-widgetbar collapsed" data-x-toggle="collapse-b" data-x-toggleable="x-widgetbar" aria-expanded="false" aria-controls="x-widgetbar" role="button">
      <i class='x-framework-icon x-icon-plus-circle' data-x-icon-s='&#xf055;' aria-hidden=true><span class="visually-hidden">Toggle the Widgetbar</span></i>    </a>

    
    <span class="x-scroll-top right fade" title="Back to Top" data-rvt-scroll-top>
      <i class='x-framework-icon x-icon-angle-up' data-x-icon-s='&#xf106;' aria-hidden=true></i>    </span>

  
  </div> <!-- END .x-root -->

<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/*"},{"not":{"href_matches":["/wp-*.php","/wp-admin/*","/wp-content/uploads/*","/wp-content/*","/wp-content/plugins/*","/wp-content/themes/pro-child/*","/wp-content/themes/pro/*","/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
<script id="cs-js-extra">
var csJsData = {"linkSelector":"#x-root a[href*=\"#\"]","bp":{"base":4,"ranges":[0,480,767,979,1200],"count":4}};
//# sourceURL=cs-js-extra
</script>
<script id="cs-js" src="https://comicbookreadingorders.com/wp-content/themes/pro/cornerstone/assets/js/site/cs-classic.7.9.4.js?ver=7.9.4"></script>
<script id="wp-hooks-js" src="https://comicbookreadingorders.com/wp-includes/js/dist/hooks.min.js?ver=f0f188028580e8dc1255"></script>
<script id="wp-i18n-js" src="https://comicbookreadingorders.com/wp-includes/js/dist/i18n.min.js?ver=1dfe7db3940c23ea9216"></script>
<script id="wp-i18n-js-after">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
//# sourceURL=wp-i18n-js-after
</script>
<script id="swv-js" src="https://comicbookreadingorders.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=6.1.7"></script>
<script id="contact-form-7-js-before">
var wpcf7 = {
    "api": {
        "root": "https:\/\/comicbookreadingorders.com\/wp-json\/",
        "namespace": "contact-form-7\/v1"
    },
    "cached": 1
};
//# sourceURL=contact-form-7-js-before
</script>
<script id="contact-form-7-js" src="https://comicbookreadingorders.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=6.1.7"></script>
<script id="patreon-wordpress-js-js" src="https://comicbookreadingorders.com/wp-content/plugins/patron-plugin-pro/plugin/lib/patreon-connect/assets/js/app.js?ver=7.1"></script>
<script id="x-site-js-extra">
var xJsData = {"scrollTop":"0.15","icons":{"down":"\u003Ci class='x-framework-icon x-icon-angle-double-down' data-x-icon-s='&#xf103;' aria-hidden=true\u003E\u003C/i\u003E","subindicator":"\u003Ci class=\"x-icon x-framework-icon x-icon-angle-double-down\" aria-hidden=\"true\" data-x-icon-s=\"&#xf103;\"\u003E\u003C/i\u003E","previous":"\u003Ci class='x-framework-icon x-icon-previous' data-x-icon-s='&#xf053;' aria-hidden=true\u003E\u003C/i\u003E","next":"\u003Ci class='x-framework-icon x-icon-next' data-x-icon-s='&#xf054;' aria-hidden=true\u003E\u003C/i\u003E","star":"\u003Ci class='x-framework-icon x-icon-star' data-x-icon-s='&#xf005;' aria-hidden=true\u003E\u003C/i\u003E"}};
//# sourceURL=x-site-js-extra
</script>
<script id="x-site-js" src="https://comicbookreadingorders.com/wp-content/themes/pro/framework/dist/js/site/x.js?ver=6.9.4"></script>
<script id="x-stack-js-extra">
var xJsStackData = {"backstretch":[["//comicbookreadingorders.com/wp-content/uploads/cbro.background.newest.svg"],{"fade":"0"}]};
//# sourceURL=x-stack-js-extra
</script>
<script id="x-stack-js" src="https://comicbookreadingorders.com/wp-content/themes/pro/framework/dist/js/site/stack.js?ver=6.9.4"></script>
<script id="google-recaptcha-js" src="https://www.google.com/recaptcha/api.js?render=6LclB9cpAAAAACO0ll7AO-d19qCvlpam6jGTRIbh&#038;ver=3.0"></script>
<script id="wp-polyfill-js" src="https://comicbookreadingorders.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0"></script>
<script id="wpcf7-recaptcha-js-before">
var wpcf7_recaptcha = {
    "sitekey": "6LclB9cpAAAAACO0ll7AO-d19qCvlpam6jGTRIbh",
    "actions": {
        "homepage": "homepage",
        "contactform": "contactform"
    }
};
//# sourceURL=wpcf7-recaptcha-js-before
</script>
<script id="wpcf7-recaptcha-js" src="https://comicbookreadingorders.com/wp-content/plugins/contact-form-7/modules/recaptcha/index.js?ver=6.1.7"></script>
<script id="wp-emoji-settings" type="application/json">
{"baseUrl":"https://s.w.org/images/core/emoji/17.0.2/72x72/","ext":".png","svgUrl":"https://s.w.org/images/core/emoji/17.0.2/svg/","svgExt":".svg","source":{"concatemoji":"https://comicbookreadingorders.com/wp-includes/js/wp-emoji-release.min.js?ver=7.1"}}
</script>
<script type="module">
/*! This file is auto-generated */
var e="script#wp-emoji-settings",t=document.querySelector(e);if(!(t instanceof HTMLScriptElement))throw new Error("Element missing: "+e);const r=JSON.parse(t.text),s=(window._wpemojiSettings=r,"wpEmojiSettingsSupports"),o=["flag","emoji"];function i(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(s,JSON.stringify(t))}catch(e){}}function c(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0);const r=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);return t.every((e,t)=>e===r[t])}function p(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var n=e.getImageData(16,16,1,1);for(let e=0;e<n.data.length;e++)if(0!==n.data[e])return!1;return!0}function u(e,t,n,r){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!r(e,"\ud83e\u1fac8")}return!1}function f(e,t,n,r){let a;const s=(a="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):document.createElement("canvas")).getContext("2d",{willReadFrequently:!0}),o=(s.textBaseline="top",s.font="600 32px Arial",{});return e.forEach(e=>{o[e]=t(s,e,n,r)}),o}function a(e){var t=document.createElement("script");t.src=e,t.defer=!0,document.head.appendChild(t)}r.supports={everything:!0,everythingExceptFlag:!0},new Promise(t=>{let n=function(){try{var e=JSON.parse(sessionStorage.getItem(s));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(o),u.toString(),c.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"});const a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=e=>{i(n=e.data),a.terminate(),t(n)})}catch(e){}i(n=f(o,u,c,p))}t(n)}).then(e=>{for(const n in e)r.supports[n]=e[n],r.supports.everything=r.supports.everything&&r.supports[n],"flag"!==n&&(r.supports.everythingExceptFlag=r.supports.everythingExceptFlag&&r.supports[n]);var t;r.supports.everythingExceptFlag=r.supports.everythingExceptFlag&&!r.supports.flag,r.supports.everything||((t=r.source||{}).concatemoji?a(t.concatemoji):t.wpemoji&&t.twemoji&&(a(t.twemoji),a(t.wpemoji)))});
//# sourceURL=https://comicbookreadingorders.com/wp-includes/js/wp-emoji-loader.min.js
</script>

</body>
</html>

<!-- Page cached by LiteSpeed Cache 7.9.1 on 2026-09-17 10:26:44 -->